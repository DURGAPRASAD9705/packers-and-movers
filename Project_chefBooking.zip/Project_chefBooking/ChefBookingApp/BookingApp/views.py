from django.shortcuts import render
from django.http import HttpResponse
from Database_chef.models import Chef_Info
from django.contrib.auth.decorators import login_required

# Create your views here.
def Homepage(request):
    obj=Chef_Info.objects.all()
    return render(request,'BookingApp/mainhome.html',{'data':obj})
def ContactPage(request):
    return render(request,'BookingApp/contact.html')
def AboutPage(request):
    return render(request,'BookingApp/about.html')
def WorksPage(request):
    return render(request,'BookingApp/works.html')
def MainPage(request):
    return render(request,'BookingApp/mainlogins.html')
