from django.urls import path
from . import views
urlpatterns=[
   
    path('home/',views.Homepage,name='mainhomeurl'),
    path('contact/',views.ContactPage,name='contacturl'),
    path('about/',views.AboutPage,name='abouturl'),
    path('hiw/',views.WorksPage,name='workurl'),
    path('login',views.MainPage,name='mainurl')
]