from django.db import models

# Create your models here.
class Chef_Info(models.Model):
    Chef_no=models.IntegerField(primary_key=True)
    Chef_Name=models.CharField(max_length=100)
    Chef_Address=models.CharField(max_length=120)
    Chef_type=models.CharField(max_length=50,null=True)
    PhoneNumber=models.BigIntegerField()
    WhatsApp=models.BigIntegerField()
    Email= models.EmailField(max_length=124, unique=True)
    Image=models.ImageField(upload_to='image/',null=True)
    Experience=models.CharField(max_length=100)
