from django import forms
from django.forms import ModelForm
from .models import Chef_Info
class ChefModelForm(forms.ModelForm):
    class Meta:
        model=Chef_Info
        fields='__all__'