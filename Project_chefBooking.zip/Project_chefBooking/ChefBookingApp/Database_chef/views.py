from django.shortcuts import render
from django.http import HttpResponse
from .forms import ChefModelForm

# Create your views here.
def StoreChef_Info(request):
    empty=ChefModelForm()
    if request.method=='POST':
        data=ChefModelForm(request.POST,request.FILES)
        if data.is_valid()==True:
            data.save()
            return render(request,'Database_chef/chefstore.html',{'form':empty,'data':'data is saved'})
        else:
            print(data.errors)
            return render(request,'Database_chef/chefstore.html',{'form':empty,'data':'data is not saved','errors':data.errors})
    return render(request,'Database_chef/chefstore.html',{'form':empty}) 