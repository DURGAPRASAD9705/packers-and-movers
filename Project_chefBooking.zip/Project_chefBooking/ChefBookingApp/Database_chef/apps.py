from django.apps import AppConfig


class DatabaseChefConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Database_chef'
