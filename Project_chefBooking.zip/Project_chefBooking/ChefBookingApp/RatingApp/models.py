from django.db import models

# Create your models here.

# class Review(models.Model):
#     # product=models.ForeignKey(Prodect, on_delete=models.CASCADE)
#     user=models.