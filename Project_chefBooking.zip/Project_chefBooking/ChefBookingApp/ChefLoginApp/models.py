from django.db import models

# Create your models here.

from django.db import models

# Create your models here.

class Gender(models.Model):
    Gender = models.CharField(max_length=7, primary_key=True)
   
    
class ChefRegisterPage(models.Model):
    First_Name = models.CharField(max_length=20)
    Last_Name = models.CharField(max_length=20)
    Mobile_Number = models.BigIntegerField(primary_key=True)
    Email= models.EmailField(max_length=124, unique=True)
    Image = models.ImageField(upload_to='images/',null=True)
    Gender = models.ForeignKey(Gender,on_delete=models.SET_NULL,null=True)
    Password = models.CharField(max_length=20) 
    Confirm_Password = models.CharField(max_length=20)

    Chef_type=models.CharField(max_length=20)# pro..home
    