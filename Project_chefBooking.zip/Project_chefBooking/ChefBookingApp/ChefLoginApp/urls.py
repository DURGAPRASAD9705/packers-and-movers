from django.urls import path
from . import views
urlpatterns=[
    path('login/',views.ChefLoginPage,name='chefloginurl'),
    path('chefsignup/',views.ChefSignupPage,name='chefSignupurl'),
    path('detail/<int:cno>',views.ChefDetailPage,name='chefdetailurl'),
]   