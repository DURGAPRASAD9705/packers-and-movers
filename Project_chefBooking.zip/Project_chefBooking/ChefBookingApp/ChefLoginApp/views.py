from django.shortcuts import render,redirect
from Database_chef.forms import Chef_Info
from .forms import RegisterModelForm,ChefLoginModelForm
from django.contrib.auth import authenticate,login,logout
from .models import ChefRegisterPage


# Create your views here.
def ChefLoginPage(request):
    if request.method=='POST':
        chefname=request.POST['chef']
        pwd=request.POST['pwd']
        data=ChefRegisterPage.objects.get(First_Name=chefname)
        if data.Password==pwd:
            return redirect('mainhomeurl')
        else:
            return redirect('chefloginurl')
    return render(request,'ChefLoginApp/cheflogin.html')

def ChefSignupPage(request):
    empty=RegisterModelForm()
    if request.method=='POST':
        data=RegisterModelForm(request.POST,request.FILES)
        if data.is_valid()==True:
            data.save()
            return redirect('chefloginurl')
        else:
            print(data.errors)
            return redirect('chefSignupurl')
    return render(request,'ChefLoginApp/chefsignup.html',{'form':empty})
def ChefDetailPage(request,cno):
    info=Chef_Info.objects.get(Chef_no=cno)
    return render(request,'ChefLoginApp/detailchef.html',{'data':info})