from django import forms
from .models import Gender,ChefRegisterPage
from django.forms import ModelForm

class RegisterModelForm(forms.ModelForm):
    class Meta:
        model=ChefRegisterPage
        fields='__all__'

class ChefLoginModelForm(forms.ModelForm):
    class Meta:
        model=ChefRegisterPage
        fields=['First_Name','Password']

