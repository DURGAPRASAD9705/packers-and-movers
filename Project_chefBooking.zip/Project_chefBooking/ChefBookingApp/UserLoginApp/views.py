from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from . forms import SignupForm
from django.contrib import messages

# Create your views here.
def UserLoginPage(request):
    if request.method=='POST':
        user=request.POST['user']
        pwd=request.POST['pwd']
        validuser=authenticate(request,username=user,password=pwd)
        if validuser!=None:
            login(request,validuser)
            return redirect('mainhomeurl')
        else:
            return redirect('userloginurl')  
    return render(request,'UserLoginApp/userlogin.html')
def UserSignupPage(request):
    empty=SignupForm()
    if request.method=='POST':
        data=SignupForm(request.POST)
        if data.is_valid()==True:
            data.save()
            messages.success(request,'succssfully signup')
            return redirect('userloginurl')
        else:
            messages.error(request,'your signup is failed')
            messages.error(request,data.errors)
            return redirect('usersignupurl')

    return render(request,'UserLoginApp/usersignup.html',{'form':empty})
