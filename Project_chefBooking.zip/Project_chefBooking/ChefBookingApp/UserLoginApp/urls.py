from django.urls import path
from . import views
urlpatterns=[
    path('login/',views.UserLoginPage,name='userloginurl'),
    path('signup/',views.UserSignupPage,name='usersignupurl'),
]